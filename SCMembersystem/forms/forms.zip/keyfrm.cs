﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SKM.V3;
using SKM.V3.Methods;
using SKM.V3.Models;

namespace SCMembersystem.forms
{
    public partial class keyfrm : Form
    {
        //WyIyNzciLCJ2K2hRY2lhMk81QTZJaW5vakZvUE0rQTZpZC9nS0pPQjlTTGFSOXc0Il0=
        private string Auth = "WyIyNzciLCJ2K2hRY2lhMk81QTZJaW5vakZvUE0rQTZpZC9nS0pPQjlTTGFSOXc0Il0=";


        private bool registarx()
        {
          
var result = Key.Activate(token: Auth, parameters: new ActivateModel()
{
    Key = Properties.Settings.Default.lickey,
    ProductId = 3526,
    Sign = true,
    MachineCode = SKGL.SKM.getMachineCode(SKGL.SKM.getSHA1)
        });

            if (result == null || result.Result == ResultType.Error)
            {
                // an error occured or the key is invalid or it cannot be activated
                // (eg. the limit of activated devices was achieved)
                return false;
            }
            var lic = result.LicenseKey;
            lic.SaveToFile("lic.key");
            return true;
// everything went fine if we are here!
        }
    public keyfrm()
        {
            InitializeComponent();

                        keytxt.Text = Properties.Settings.Default.lickey;
        }

        private void keyfrm_Load(object sender, EventArgs e)
        {
            
        }

        private void savebut_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.lickey = keytxt.Text;
            Properties.Settings.Default.Save();
            if (registarx())
            {
                messkey.Text = "Your key is valid. Please close the app and restart";
            }
            else
            {
                messkey.Text = "Your key is invalid.";

            }
        }
    }
}
